# Nillar Identity for Node.js

Server-only client for Node.js 20.11 and newer. Store the API key in your server's secret manager, never a browser environment variable. This package is delivered as a private tarball; it has not been published to npm.

```ts
import { randomUUID } from 'node:crypto'
import { NillarIdentity } from '@nillar/identity-node'

const identity = new NillarIdentity({ apiKey: process.env.NILLAR_IDENTITY_API_KEY! })
const { verification, launchUrl } = await identity.createVerification({
  customerReference: 'customer_123',
  reference: 'onboarding_123',
  policyCode: 'CONSUMER_VA_P0',
}, { idempotencyKey: randomUUID() })
// Persist the idempotency key before calling the API; reuse it for retries.
// Share launchUrl securely. Its one-time ticket is in the URL fragment.
```

`CONSUMER_VA_P0` selects the partner personal-identity profile; partner requests are mapped to a separate Identity-only policy, not virtual-account activation. `BUSINESS_P0` requires separately activated business verification services in live mode.

Read status using `getVerification(id)`, list with cursor pagination using `listVerifications()`, cancel using `cancelVerification(id)`, or invalidate an old link using `renewVerificationLink(id)`. Sandbox/live environment is determined by the API key. The SDK preserves the idempotency key across bounded create retries. Cancel and renewal are not retried automatically.

```ts
import { constructWebhookEvent } from '@nillar/identity-node'
const event = constructWebhookEvent({
  body: rawRequestBody,
  signature: request.headers['nillar-signature'],
  secret: process.env.NILLAR_WEBHOOK_SECRET!,
})
// Enforce environment, deduplicate event.id in durable storage, acknowledge
// promptly and process asynchronously. Never verify a re-serialized JSON body.
```

Webhooks are delivered at least once and can be retried. Signatures bind the exact body and timestamp, allow up to five minutes of age and at most sixty seconds of future clock skew. Keep clocks synchronised. Signature verification does not deduplicate events for you. A browser redirect does not establish an approved verification.
